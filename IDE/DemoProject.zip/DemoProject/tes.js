describe('Smokeflow', function() {it('should be created', function() { 
browser.get('http://cafetownsend-angular-rails.herokuapp.com/login'); 
element(by.model('user.name')).sendKeys('Luke'); 
element(by.model('user.password')).sendKeys('Skywalker'); 
element(by.xpath('//*[@id="login-form"]/fieldset/button')).click(); 
browser.close(); 
});});